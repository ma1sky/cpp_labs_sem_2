#ifndef LETTER_UTILS_H
#define LETTER_UTILS_H
#include "letter.h"
#include <iostream>
using namespace std;
const int maxLen = 64;

void printTableLetter();
letter& createLetter();
fio& createFIO();
#endif