#pragma once
using namespace std;
#define _CRT_SECURE_NO_WARNINGS
#include <iostream>
#include <ostream>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <fstream>
#include <iomanip>
#include <algorithm>
#include <functional>
#include <deque>

#include "fio.h"
#include "letter.h"
#include "letter_utils.h"
#include "file_operations.h"