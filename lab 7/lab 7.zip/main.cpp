﻿#include "main.h"

int main() {
    const char* filename = "DataBase.txt";
    bool flag = false;
    fio findFIO;
    int delIndex;
    deque<letter> letters;
    deque<letter>::iterator it;
    deque<letter> lettersByFIO;
    readData(letters, filename);
    int choice;

    do {
        cout << "Choose option" << endl;
        cout << "1. Add new letter in back" << endl;
        cout << "2. Add new letter in front" << endl;
        cout << "3. Delete element" << endl;
        cout << "4. Print data" << endl;
        cout << "5. Find letter by FIO" << endl;
        cout << "6. Sort by price" << endl;
        cout << "7. Sort by family name" << endl;
        cout << "8. Exit" << endl;
        cout << "Your choice: ";
        cin >> choice;

        if (cin.fail() || choice < 0 || choice > 8) {
            cout << "Invalid input. Please enter a valid choice." << endl;
            cin.clear();
            cin.ignore(numeric_limits<streamsize>::max(), '\n');
            continue;
        }
        cin.ignore(numeric_limits<streamsize>::max(), '\n');
        switch (choice) {
        case 1:
            letters.push_back(createLetter());
            break;
        case 2:
            letters.push_front(createLetter());
            break;
        case 3:
            do {
                cout << '\n' << "Enter number of object: ";
                cin >> delIndex;
                if (cin.fail() || delIndex >= letters.size() || delIndex <= 0) {
                    cout << "Incorrect input" << endl;
                    cin.clear();
                    cin.ignore(numeric_limits<streamsize>::max(), '\n');
                }
            } while (cin.fail() || delIndex >= letters.size() || delIndex <= 0);
            it = letters.begin() + delIndex - 1;
            letters.erase(it);
            break;
        case 4:
            printTableLetter();
            for (const letter& message: letters) {
                cout << message << endl;
            }
            break;
        case 5:
            do {
                findFIO = createFIO();
                for (it = letters.begin(); it != letters.end(); it++) {
                    if (it->getFIO() == findFIO) {
                        lettersByFIO.push_back(*it); // Добавляем найденное письмо в вектор
                    }
                }
                void printTableLetter();
                for (letter message : lettersByFIO) {
                    cout << message << endl;
                }
            } while (flag != 0);
            break;
        case 6:
            sort(letters.begin(), letters.end(), less<letter>());
            break;
        case 7:
            sort(letters.begin(), letters.end(), greater<letter>());
            break;
        case 8:
            saveData(letters, filename);
            letters.clear();
            return 0;
            break;
        default:
            cout << "Invalid choice. Please enter a valid option." << endl;
            break;
        }

    } while (choice != 8);

    return 0;
}